import streamlit as st
from model import doUserTesting
import pandas as pd
st.title("Chaitanya Jagtap")

data = pd.read_csv('Train_set')
# st.text("RAW DATA")
# st.dataframe(data)


v1=st.text_input("Enter the News")

if st.button("Proceed to predict"):
    prediction=doUserTesting(v1)
    st.text("PREDICTIONS ARE")
    st.text(prediction)